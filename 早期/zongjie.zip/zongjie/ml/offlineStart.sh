export AppUnicodeType=utf16
nohup python -u OfflineData.py > logs/OfflineData.log &

