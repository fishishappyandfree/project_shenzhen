
ps -ef|grep dataflow.py |grep -v grep | awk '{print $2}' |xargs kill -9
